using UnityEngine;

public class EnemyDetector : MonoBehaviour
{
    [SerializeField] Collider2D detector;

    EnemyAI enemyAI;    
    GameObject player;

    void Awake()
    {
        enemyAI = GetComponentInParent<EnemyAI>();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (enemyAI == null || !enemyAI.isActiveAndEnabled)
        {
            return;
        }

        if (collision.CompareTag("Player"))
        {
            player = collision.gameObject;

            enemyAI.StartChasing(player);
        }
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        if (enemyAI == null || !enemyAI.isActiveAndEnabled)
        {
            return;
        }

        if (collision.CompareTag("Player"))
        {
            player = collision.gameObject;

            enemyAI.StartChasing(player);
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (enemyAI == null || !enemyAI.isActiveAndEnabled)
        {
            return;
        }

        if (collision.CompareTag("Player"))
        {
            player = null;

            enemyAI.StopChasing();
        }
    }

    void OnDisable()
    {
        player = null;
    }
}
