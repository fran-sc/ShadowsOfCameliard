using UnityEngine;

public class EnemyAttackEvent : MonoBehaviour
{
    [SerializeField] AudioManager.Effect attackSound; // Sonido de ataque del enemigo
    EnemyAI enemyAI;

    void Awake()
    {
        enemyAI = GetComponentInParent<EnemyAI>();
    }

    public void OnAttackAnimationEvent()
    {
        // Reproducimos el sonido de ataque del enemigo
        if (attackSound != AudioManager.Effect.None)
        {
            AudioManager.Instance.PlayEffect(attackSound);
        }

        // Llamamos al método DealAttackDamage del EnemyAI
        DealAttackDamage();
    }

    void DealAttackDamage()
    {
        if (enemyAI != null)
        {
            enemyAI.DealAttackDamage();
        }
    }
}
