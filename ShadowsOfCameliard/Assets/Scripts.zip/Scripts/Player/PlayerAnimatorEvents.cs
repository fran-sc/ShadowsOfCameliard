using UnityEngine;

public class PlayerAnimatorEvents : MonoBehaviour
{
    PlayerController playerController;

    void Start()
    {
        playerController = GetComponentInParent<PlayerController>();
    }

    void OnAttackStart()
    {
        playerController.SetAttackingFlag(true);
    }

    void OnAttackEnd()
    {
        playerController.SetAttackingFlag(false);
    }
}
