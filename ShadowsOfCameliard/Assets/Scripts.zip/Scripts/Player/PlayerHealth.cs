using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealth : DamageReceiver
{
    [Header("Hit Effect")]
    [SerializeField] private Color hitColor = Color.red;
    [SerializeField] private float hitTime = 0.1f;

    [Header("Idle Regeneration")]
    [SerializeField] private bool enableIdleRegeneration = true;
    [SerializeField] private int idleHealLimit = 3;
    [SerializeField] private float idleHealInterval = 3f;
    [SerializeField] private float idleMovementThreshold = 0.05f;
    [SerializeField] private AudioManager.Effect healerSound;

    SpriteRenderer spriteRenderer;
    Material material;
    Coroutine hitEffectCoroutine;

    Rigidbody2D rb;
    Animator anim;

    float idleTimer;

    bool IsPlayerIdle => 
        PlayerController.Instance.Movement.magnitude < idleMovementThreshold;

    protected override void Start()
    {
        base.Start();

        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        anim = GetComponentInChildren<Animator>();

        if (spriteRenderer != null)
        {
            material = spriteRenderer.material;
        }

        rb = GetComponent<Rigidbody2D>();

        UpdateHealthUI();
    }

    private void Update()
    {
        HandleIdleRegeneration();
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;

        if (material != null)
        {
            material.color = Color.white;
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        UpdateHealthUI();
    }

    public override void TakeDamage(int damage)
    {
        if (PlayerController.Instance != null && PlayerController.Instance.IsBlocking)
        {
            AudioManager.Instance.PlayEffect(AudioManager.Effect.ShieldBlock);
            return;
        }

        base.TakeDamage(damage);
        idleTimer = 0f;
    }

    protected override void OnDamaged(int damage)
    {
        UpdateHealthUI();

        PlayHitEffect();
    }

    protected override void OnHealed(int amount)
    {
        UpdateHealthUI();

        if (healerSound != AudioManager.Effect.None)
        {
            AudioManager.Instance.PlayEffect(healerSound);
        }
    }

    protected override void Die()
    {
        StartCoroutine(DeathCoroutine());
    }

    IEnumerator DeathCoroutine()
    {
        // Desactivamos los controles del jugador
        InputManager.Instance.Controls.Player.Disable();

        // Desactivamos el rigibody del jugador
        if (rb != null)
        {
            rb.simulated = false;
        }

        // Reproducimos la animacion de muerte del jugador
        if (anim != null)
        {
            anim.SetTrigger("death");
        }

        // Esperamos un tiempo antes de reiniciar la escena
        yield return new WaitForSeconds(2f);

        // Hacemos un fade out de la pantalla antes de reiniciar la escena
        UIFade.Instance.FadeToBlack();
        yield return new WaitForSeconds(UIFade.Instance.FadeDuration);

        // Reiniciamos el estado del jugador
        isDead = false;
        currentHealth = maxHealth;
        UpdateHealthUI();

        if (rb != null)
        {
            rb.simulated = true;
        }

        // Esperamos un frame para asegurarnos de que la escena se haya reiniciado
        yield return null;

        // Reiniciamos la escena actual
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);        
    }

    private void HandleIdleRegeneration()
    {
        if (!enableIdleRegeneration) return;
        if (isDead) return;
        if (currentHealth >= idleHealLimit) return;

        if (IsPlayerIdle)
        {
            idleTimer += Time.deltaTime;

            if (idleTimer >= idleHealInterval)
            {
                Heal(1);
                idleTimer = 0f;
            }
        }
        else
        {
            idleTimer = 0f;
        }
    }
    

    private void UpdateHealthUI()
    {
        if (UIManager.Instance != null)
        {
            UIManager.Instance.UpdateHealth(currentHealth, maxHealth);
        }
    }

    private void PlayHitEffect()
    {
        if (material == null) return;

        if (hitEffectCoroutine != null)
        {
            StopCoroutine(hitEffectCoroutine);
        }

        hitEffectCoroutine = StartCoroutine(HitEffectRoutine());
    }

    private IEnumerator HitEffectRoutine()
    {
        material.color = hitColor;

        yield return new WaitForSeconds(hitTime);

        material.color = Color.white;
        hitEffectCoroutine = null;
    }
}