using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// -----------------------------------------------------------------------------
// Esta clase maneja los efectos de desvanecimiento de la interfaz de usuario
// El efecto de desvanecimiento se aplica a un componente de imagen (Image) de 
// la UI que cubre toda la pantalla.
// -----------------------------------------------------------------------------
public class UIFade : PersistentSingleton<UIFade>
{
    [SerializeField] Image fadeImage;
    [SerializeField] float fadeDuration;

    public float FadeDuration => fadeDuration;

    private IEnumerator fadeCoroutine;

    public void FadeToBlack()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        Color color = fadeImage.color;
        color.a = 0f;
        fadeImage.color = color;

        fadeCoroutine = Fade(1f);
        StartCoroutine(fadeCoroutine);
    }

    public void FadeFromBlack()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        Color color = fadeImage.color;
        color.a = 1f;
        fadeImage.color = color;

        fadeCoroutine = Fade(0f);

        StartCoroutine(fadeCoroutine);
    }

    private IEnumerator Fade(float targetAlpha)
    {
        Color color = fadeImage.color;
        float startAlpha = color.a;
        float time = 0;

        while (time < fadeDuration)
        {
            time += Time.deltaTime;
            color.a = Mathf.Lerp(startAlpha, targetAlpha, time / fadeDuration);
            fadeImage.color = color;
            yield return null;
        }
    }
}
