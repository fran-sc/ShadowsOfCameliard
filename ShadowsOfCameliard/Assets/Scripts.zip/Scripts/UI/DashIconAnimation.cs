using UnityEngine;
using UnityEngine.UI;

public class DashIconAnimation : MonoBehaviour
{
    Image cooldownImage;
    Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        cooldownImage = GetComponent<Image>();
    }

    void Update()
    {
        cooldownImage.fillAmount = PlayerController.Instance.DashCooldownNormalized;

        if (cooldownImage.fillAmount >= 1f)
        {
            Active();
        }
    }

    public void Active()
    {
        anim.SetTrigger("active");
    }

    public void Fire()
    {
        anim.SetTrigger("fire");
    }

    public void Reset()
    {
        anim.Rebind();
    }
}
