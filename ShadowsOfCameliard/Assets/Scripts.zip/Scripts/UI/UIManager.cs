using Unity.VisualScripting;
using UnityEngine;

public class UIManager : PersistentSingleton<UIManager>
{
    [Header("Health UI Settings")]
    [SerializeField] GameObject heartPrefab;
    [SerializeField] Transform heartContainer;
    [SerializeField] Vector2 heartSpacing;
    [SerializeField] Vector2 topLeftAnchorOffset;
    
    public void UpdateHealth(int currentHealth, int maxHealth)
    {
        // Clear existing hearts
        foreach (Transform child in heartContainer)
        {
            Destroy(child.gameObject);
        }

        // Calculate the starting position for the hearts
        Vector2 startPosition = new Vector2(topLeftAnchorOffset.x, -topLeftAnchorOffset.y);

        // Instantiate hearts based on current health
        for (int i = 0; i < maxHealth; i++)
        {
            GameObject heart = Instantiate(heartPrefab, heartContainer);
            RectTransform heartRect = heart.GetComponent<RectTransform>();
            heartRect.anchoredPosition = startPosition + new Vector2(i * heartSpacing.x, 0);

            // Set the heart's active state based on current health
            heart.SetActive(i < currentHealth);
        }
    }
}
