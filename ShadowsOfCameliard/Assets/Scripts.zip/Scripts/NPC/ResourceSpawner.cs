using UnityEngine;

public class ResourceSpawner : MonoBehaviour
{
    // Identificador del objeto spawndeado por el NPC
    [SerializeField] string spawnOnceID;
    [SerializeField] bool useCurrentPosition;
    [SerializeField] Vector3 offsetPosition;

    public void SpawnResource()
    {
        if (!CheckResourceToSpawn())
        {
            return;
        }

        if (useCurrentPosition)
        {
            Vector3 spawnPosition = transform.position + offsetPosition;
            SceneManagement.Instance.SpawnResource(spawnOnceID, spawnPosition);
        }
        else
        {
            SceneManagement.Instance.SpawnResource(spawnOnceID);
        }
    }

    public bool CheckResourceToSpawn()
    {
        SpawnOnceSO resource = ResourcesManager.Instance.GetResource(spawnOnceID);
        
        return resource != null && 
            resource.state == SpawnOnceSO.SpawnOnceState.NotSpawned;
    }
}
