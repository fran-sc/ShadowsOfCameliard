using UnityEngine;

// -----------------------------------------------------------------------------
// Activa el collider del arma solo durante la animación de ataque
// -----------------------------------------------------------------------------
public class WeaponCollider : MonoBehaviour
{
    [SerializeField] Collider2D weaponCollider;
    PlayerController playerController;

    void Start()
    {
        playerController = PlayerController.Instance;
    }

    void Update()
    {
        UpdateWeaponColliderState();
    }

    void UpdateWeaponColliderState()
    {
        weaponCollider.enabled = playerController.IsAttacking;
    }
}

