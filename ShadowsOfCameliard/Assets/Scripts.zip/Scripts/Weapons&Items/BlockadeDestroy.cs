using UnityEngine;

public class BlockadeDestroy : MonoBehaviour
{
    [SerializeField] Sprite destroyedSprite;
    SpriteRenderer sr;
    
    void Start()
    {
        sr = GetComponentInChildren<SpriteRenderer>();
    }

    public void DestroyBlockade()
    {
        // Cambiamos el sprite del objeto a la versión destruida
        sr.sprite = destroyedSprite;

        // Desactivamos el collider para que el jugador pueda pasar
        GetComponent<Collider2D>().enabled = false; 

        // Cambiamos el estado del recurso en el ResourcesManager para que no 
        // vuelva a aparecer al cargar la escena
        SpawnOnceSO resource = ResourcesManager.Instance.GetResource(gameObject.name);
        if (resource != null)
        {
            resource.state = SpawnOnceSO.SpawnOnceState.Destroyed;
        }
    }
}
