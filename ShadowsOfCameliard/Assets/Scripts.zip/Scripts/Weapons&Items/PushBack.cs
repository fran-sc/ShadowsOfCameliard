using System.Collections;
using NUnit.Framework;
using UnityEngine;

public class PushBack : MonoBehaviour
{
    [SerializeField] float pushTime = 0.25f;

    Rigidbody2D rb;
    Coroutine stopPushCoroutine;

    public bool IsPushed {get; private set;} = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    public void Push(Vector2 direction, float force)
    {
        if (rb == null)
        {
            Debug.LogWarning("PushBack: Rigidbody2D no encontrado.");
            return;
        }

        if (stopPushCoroutine != null)
        {
            StopCoroutine(stopPushCoroutine);
            stopPushCoroutine = null;
        }

        IsPushed = true;

        // Cancelamos valocidad anterior para que el empuje sea consistente
        rb.linearVelocity = Vector2.zero;
        rb.angularVelocity = 0f;

        rb.AddForce(direction * force * rb.mass, ForceMode2D.Impulse);
        
        stopPushCoroutine = StartCoroutine(StopPush());
    }

    IEnumerator StopPush()
    {
        yield return new WaitForSeconds(pushTime);
        
        StopPushInmediately();
    }

    void StopPushInmediately()
    {
        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.angularVelocity = 0f;
        }

        IsPushed = false;
        stopPushCoroutine = null;
    }

    void OnDisable()
    {
        if (stopPushCoroutine != null)
        {
            StopCoroutine(stopPushCoroutine);
            stopPushCoroutine = null;
        }

        IsPushed = false;
    }
}
