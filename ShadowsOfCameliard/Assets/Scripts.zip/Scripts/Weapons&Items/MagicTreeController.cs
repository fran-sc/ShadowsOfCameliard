using UnityEngine;

public class MagicTreeController : MonoBehaviour
{
    [SerializeField] Collider2D solidCollider;

    Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();

        anim.enabled = false;
    }

    public void ActivateTree()
    {
        // Activamos la animación de crecimiento del árbol
        anim.enabled = true;

        // Desactivamos el collider sólido para que el jugador pueda pasar
        solidCollider.enabled = false;
    }
}
