using UnityEngine;

public class ExplosionDamageSource : DamageSource
{
    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        if (!GetComponentInParent<BombController>().HasExploded)
            return;
            
        if (collision.gameObject.GetComponent<BlockadeDestroy>() != null)
        {
            collision.gameObject.GetComponent<BlockadeDestroy>().DestroyBlockade();
            return;
        }

        base.OnTriggerEnter2D(collision);
    }
}
