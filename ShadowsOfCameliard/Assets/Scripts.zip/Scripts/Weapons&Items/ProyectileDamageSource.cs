using UnityEngine;

public class ProyectileDamageSource : DamageSource
{
    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        // Destruimos el proyectil al colisionar con cualquier objeto
        Destroy(gameObject);
    }
}
