using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CodexFade : MonoBehaviour
{
    [Header("Fade Settings")]
    [SerializeField] float fadeInDuration = 3f;
    [SerializeField] float fadeOutDuration = 3f;
    [SerializeField] Image fadeImage;
        
    IEnumerator fadeCoroutine;

    public void FadeToBlack()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        Color color = fadeImage.color;
        color.a = 0f;
        fadeImage.color = color;

        fadeCoroutine = Fade(1f, fadeOutDuration);
        StartCoroutine(fadeCoroutine);
    }

    public void FadeFromBlack()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        Color color = fadeImage.color;
        color.a = 1f;
        fadeImage.color = color;

        fadeCoroutine = Fade(0f, fadeInDuration);

        StartCoroutine(fadeCoroutine);
    }

    private IEnumerator Fade(float targetAlpha, float fadeDuration)
    {
        Color color = fadeImage.color;
        float startAlpha = color.a;
        float time = 0;

        while (time < fadeDuration)
        {
            time += Time.deltaTime;
            color.a = Mathf.Lerp(startAlpha, targetAlpha, time / fadeDuration);
            fadeImage.color = color;
            yield return null;
        }
    }   
}
