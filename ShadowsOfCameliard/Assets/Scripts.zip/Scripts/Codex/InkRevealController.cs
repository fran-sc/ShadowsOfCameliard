using System.Collections;
using UnityEngine;

public class InkRevealController : MonoBehaviour
{
    [SerializeField] private Material revealMaterial;
    [SerializeField] private float revealDuration = 2f;
    private static readonly int RevealAmountID = Shader.PropertyToID("_RevealAmount");

    void Start()
    {
        // Initialize the reveal amount to 1 (fully hidden)
        revealMaterial.SetFloat(RevealAmountID, 1f);
    }

    public void Reveal()
    {
        StopAllCoroutines();
        StartCoroutine(RevealRoutine());
    }

    private IEnumerator RevealRoutine()
    {
        float elapsed = 0f;

        revealMaterial.SetFloat(RevealAmountID, 1f);

        while (elapsed < revealDuration)
        {
            elapsed += Time.deltaTime;

            float t = Mathf.Clamp01(elapsed / revealDuration);
            revealMaterial.SetFloat(RevealAmountID, 1 - t);

            yield return null;
        }

        revealMaterial.SetFloat(RevealAmountID, 0f);
    }
}
