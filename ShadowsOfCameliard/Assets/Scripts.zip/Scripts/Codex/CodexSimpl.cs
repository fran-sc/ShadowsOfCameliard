using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class CodexSimpl : MonoBehaviour
{
    [Header("Book Settings")]
    [SerializeField] float bookWidth = 8.25f;
    [SerializeField] float bookHeight = 5.5f;
    [SerializeField] float traslationTime = 1f;
    [SerializeField] float fastTurnDuration = 0.4f;

    [Header("Codex Pages")]
    [SerializeField] CodexPageSimpl[] codexPages;
    [SerializeField] int startingPageIndex = 0;

    [Header("Camera Settings")]
    [SerializeField] Camera codexCamera;
    [SerializeField] float maxOrthographicSize = 5f;
    [SerializeField] float minOrthographicSize = 3f;

    int currentRightPageIndex = 0;

    bool isTransitionInProgress = false;
    bool isPageTurning = false;
    bool isBookMoving = false;

    int pendingPageToHideIndex = -1;

    public float Width => bookWidth;
    public float Height => bookHeight;
    public int TotalPages => codexPages.Length;
    public int CurrentRightPageIndex => currentRightPageIndex;

    void Awake()
    {
        SubscribeToPages();
    }

    void OnDestroy()
    {
        UnsubscribeFromPages();
    }

    void Start()
    {
        Vector3 initialPosition = transform.localPosition - new Vector3(bookWidth / 2f, 0f, 0f);
        transform.localPosition = initialPosition;

        if (startingPageIndex > 0)
        {
            StartCoroutine(GotoPageRoutine(startingPageIndex));
        }
    }

    void SubscribeToPages()
    {
        if (codexPages == null) return;

        foreach (CodexPageSimpl page in codexPages)
        {
            if (page == null) continue;
            page.TurnCompleted += HandlePageTurnCompleted;
        }
    }

    void UnsubscribeFromPages()
    {
        if (codexPages == null) return;

        foreach (CodexPageSimpl page in codexPages)
        {
            if (page == null) continue;
            page.TurnCompleted -= HandlePageTurnCompleted;
        }
    }

    IEnumerator GotoPageRoutine(int pageIndex)
    {
        pageIndex = Mathf.Clamp(pageIndex, 0, codexPages.Length - 1);

        while (currentRightPageIndex < pageIndex)
        {
            float originalTurnDuration = codexPages[currentRightPageIndex].TurnDuration;

            codexPages[currentRightPageIndex].SetTurnDuration(fastTurnDuration);

            GoForward();

            yield return new WaitUntil(() => !isTransitionInProgress);

            codexPages[currentRightPageIndex - 1].SetTurnDuration(originalTurnDuration);
        }
    }

    void GoForward()
    {
        if (isTransitionInProgress) return;
        if (currentRightPageIndex >= codexPages.Length - 1) return;

        isTransitionInProgress = true;
        isPageTurning = true;
        pendingPageToHideIndex = currentRightPageIndex - 1;

        if (currentRightPageIndex == 0)
        {
            RecentreBook(true);
        }

        CodexPageSimpl page = codexPages[currentRightPageIndex];
        page.TurnPage();

        currentRightPageIndex++;

        CodexPageSimpl nextPage = codexPages[currentRightPageIndex];
        nextPage.gameObject.SetActive(true);
    }

    void GoBackward()
    {
        if (isTransitionInProgress) return;
        if (currentRightPageIndex <= 0) return;

        isTransitionInProgress = true;
        isPageTurning = true;

        if (currentRightPageIndex == 1)
        {
            RecentreBook(false);
        }

        currentRightPageIndex--;

        CodexPageSimpl page = codexPages[currentRightPageIndex];
        page.gameObject.SetActive(true);
        page.TurnPage();

        pendingPageToHideIndex = currentRightPageIndex + 1;

        if (currentRightPageIndex - 1 >= 0)
        {
            CodexPageSimpl previousPage = codexPages[currentRightPageIndex - 1];
            previousPage.gameObject.SetActive(true);
        }
    }

    void HandlePageTurnCompleted(CodexPageSimpl page)
    {
        isPageTurning = false;

        HidePendingPage();

        TryFinishTransition();
    }

    void HidePendingPage()
    {
        if (pendingPageToHideIndex < 0 || pendingPageToHideIndex >= codexPages.Length)
        {
            pendingPageToHideIndex = -1;
            return;
        }

        codexPages[pendingPageToHideIndex].gameObject.SetActive(false);
        pendingPageToHideIndex = -1;
    }

    void RecentreBook(bool isOpening)
    {
        Vector3 direction = isOpening
            ? new Vector3(bookWidth / 2f, 0f, 0f)
            : new Vector3(-bookWidth / 2f, 0f, 0f);

        Vector3 targetPosition = transform.localPosition + direction;

        StartCoroutine(AnimateBookPosition(targetPosition, traslationTime));

        StartCoroutine(AnimateCameraSize(isOpening));
    }

    IEnumerator AnimateBookPosition(Vector3 targetPosition, float duration)
    {
        isBookMoving = true;

        Vector3 startPosition = transform.localPosition;
        float elapsedTime = 0f;

        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime;

            float t = Mathf.Clamp01(elapsedTime / duration);
            transform.localPosition = Vector3.Lerp(startPosition, targetPosition, t);

            yield return null;
        }

        transform.localPosition = targetPosition;

        isBookMoving = false;

        TryFinishTransition();
    }

    IEnumerator AnimateCameraSize(bool isOpening)
    {
        float targetSize = isOpening ? maxOrthographicSize : minOrthographicSize;
        float startSize = codexCamera.orthographicSize;
        float elapsedTime = 0f;

        while (elapsedTime < traslationTime)
        {
            elapsedTime += Time.deltaTime;

            float t = Mathf.Clamp01(elapsedTime / traslationTime);
            codexCamera.orthographicSize = Mathf.Lerp(startSize, targetSize, t);

            yield return null;
        }

        codexCamera.orthographicSize = targetSize;
    }

    void TryFinishTransition()
    {
        if (isPageTurning) return;
        if (isBookMoving) return;

        isTransitionInProgress = false;
    }

    public void ActionForward(InputAction.CallbackContext context)
    {
        if (!context.performed) return;

        GoForward();
    }

    public void ActionBackward(InputAction.CallbackContext context)
    {
        if (!context.performed) return;

        GoBackward();
    }
}