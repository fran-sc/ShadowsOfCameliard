using Unity.Cinemachine;
using UnityEngine;

public class CameraManager : PersistentSingleton<CameraManager>
{
    public void SetPlayerCameraFollow()
    {
        CinemachineCamera cam = FindFirstObjectByType<CinemachineCamera>();
        cam.Follow = PlayerController.Instance.transform;
    }
}
