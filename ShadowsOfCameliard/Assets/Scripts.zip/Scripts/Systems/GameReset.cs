using UnityEngine;
using UnityEngine.SceneManagement;

public static class GameReset
{
    public static void ReloadSceneFromScratch(string sceneName)
    {
        DestroyDontDestroyOnLoadObjects();

        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }   

    public static void DestroyDontDestroyOnLoadObjects()
    {
        GameObject temp = new GameObject("TempDDOLFinder");
        Object.DontDestroyOnLoad(temp);

        Scene dontDestroyScene = temp.scene;

        foreach (GameObject root in dontDestroyScene.GetRootGameObjects())
        {
            if (root != temp)
            {
                Object.Destroy(root);
            }
        }

        Object.Destroy(temp);
    }
}