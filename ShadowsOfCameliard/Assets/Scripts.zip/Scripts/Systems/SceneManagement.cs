using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagement : PersistentSingleton<SceneManagement>
{
    [Header("Game Start")]
    [SerializeField] PortalSpawn initialPortal;

    // Nombre del portal de destino al que se debe teletransportar el jugador
    public string destPortalName { get; private set; }
    public void SetDestPortalName(string name) => destPortalName = name;

    protected override void Awake()
    {
        base.Awake();

        // Si es un duplicado, salimos para evitar la suscripción múltiple al 
        // evento de carga de escena
        if (Instance != this)
        {
            return;
        }

        // Establecemos el valor inicial del portal de destino
        // Se utiliza cuando aún no se ha atravesado ningún portal y 
        // el jugador muere
        destPortalName = initialPortal != null ? initialPortal.PortalName : string.Empty;

        // Nos suscribimos al evento de carga de escena para instanciar los 
        // recursos de la escena actual una vez que la escena haya sido 
        // completamente cargada.
        SceneManager.sceneLoaded += OnSceneLoaded; 
    }
        // Nos suscribimos al evento de carga de escena para i

    protected override void OnDestroy()
    {
        if (Instance == this)
        {
            // Nos desuscribimos del evento para evitar referencias colgantes
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        base.OnDestroy();
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Instanciamos los recursos de la escena actual
        SpawnSceneResources(scene.buildIndex);
    }

    void SpawnSceneResources(int sceneID)
    {
        // Obtenemos los recursos de la escena actual
        var resources = ResourcesManager.Instance.GetSceneResources(sceneID);
        
        // Instanciamos los recursos
        foreach (var resource in resources)
        {
            if (resource.itemPrefab == null)
            {
                Debug.LogWarning($"No se ha asignado el prefab del recurso {resource.name}.");
                continue;    
            }

            // Si está pendiente de spawneo o ya ha sido spawneado (pero no
            // recogido ni destruido), lo instanciamos en la posición predeterminada
            if (resource.state == SpawnOnceSO.SpawnOnceState.ToSpawn ||
                resource.state == SpawnOnceSO.SpawnOnceState.Spawned)
            {
                GameObject gameObject = Instantiate(
                    resource.itemPrefab, resource.spawnPosition, Quaternion.identity);
                
                // Almacenamos el ID del item en el nombre del GameObject
                gameObject.name = resource.itemID; 

                // Actualizamos el estado del recurso a Spawned
                resource.state = SpawnOnceSO.SpawnOnceState.Spawned;
            }
        }
    }

    // -------------------------------------------------------------------------
    // Este método permite instanciar un recurso en la posición predeterminada
    // -------------------------------------------------------------------------
    public void SpawnResource(string resourceID)
    {
        SpawnOnceSO resource = ResourcesManager.Instance.GetResource(resourceID);

        if (resource == null)
        {
            Debug.Log($"SceneManagement.SpawnResource(): resource {resourceID} not found.");
            return;
        }

        Vector3 position = ResourcesManager.Instance.GetResource(resourceID).spawnPosition;

        SpawnResource(resourceID, position);
    }

    // -------------------------------------------------------------------------
    // Este método permite instanciar un recurso en una posición específica
    // -------------------------------------------------------------------------
    public void SpawnResource(string resourceID, Vector3 position)
    {
        var resource = ResourcesManager.Instance.GetResource(resourceID);
        
        if (resource != null)
        {
            if (resource.itemPrefab != null)
            {
                // Instanciamos el recurso en la posición especificada
                GameObject gameObject = Instantiate(resource.itemPrefab, position, Quaternion.identity);
                
                // Almacenamos el ID del item en el nombre del GameObject
                gameObject.name = resource.itemID; 

                // Actualizamos el estado del recurso a Spawned
                resource.state = SpawnOnceSO.SpawnOnceState.Spawned;
            }
            else
            {
                Debug.LogWarning($"Prefab for resource {resource.name} is not assigned.");
            }
        }
    }

}
