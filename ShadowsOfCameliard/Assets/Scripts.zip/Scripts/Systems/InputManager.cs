using UnityEngine;

public enum ControlMap
{
    Player,
    Inventory,
    Dialogue,
    Menu
}

// -----------------------------------------------------------------------------
// Gestor centralizado de input para los diferentes mapas de controles del juego
// -----------------------------------------------------------------------------
public class InputManager : PersistentSingleton<InputManager>
{
    PlayerControls controls;

    public PlayerControls Controls => controls;

    ControlMap currentMap = ControlMap.Player;

    protected override void Awake()
    {
        base.Awake();

        // Si este InputManager es un duplicado, base.Awake() ya habrá llamado
        // a Destroy(gameObject).
        // Salimos para no crear otro PlayerControls.
        if (Instance != this)
        {
            return;
        }

        controls = new PlayerControls();

        SwitchMap(currentMap);
    }

    void OnEnable()
    {
        if (Instance != this || controls == null)
        {
            return;
        }

        SwitchMap(currentMap);
    }

    void OnDisable()
    {
        if (Instance != this || controls == null)
        {
            return;
        }

        controls.Disable();
    }

    protected override void OnDestroy()
    {
        if (Instance == this && controls != null)
        {
            controls.Disable();
            controls.Dispose();
            controls = null;
        }

        base.OnDestroy();
    }

    // -------------------------------------------------------------------------
    // Establece el mapa de controles activo
    // -------------------------------------------------------------------------
    public void SwitchMap(ControlMap newMap)
    {
        if (controls == null)
        {
            return;
        }

        currentMap = newMap;

        controls.Player.Disable();
        controls.Inventory.Disable();
        controls.UI.Disable();

        switch (newMap)
        {
            case ControlMap.Player:
                controls.Player.Enable();
                break;

            case ControlMap.Inventory:
                controls.Inventory.Enable();
                break;

            case ControlMap.Dialogue:
                controls.UI.Enable();
                break;

            case ControlMap.Menu:
                controls.UI.Enable();
                break;
        }
    }
}