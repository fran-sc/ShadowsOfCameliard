using System;
using UnityEngine;

public class WelcomeMessage : PersistentSingleton<WelcomeMessage>
{
    [Header("Welcome Message Settings")]
    [TextArea(3, 10)][SerializeField] string welcomeMessage;
    [SerializeField] bool showMessageOnStart = true;
    [SerializeField] float delay = 1f;

    bool wasMessageShown = false;

    void Start()
    {
        if (showMessageOnStart && !wasMessageShown)
        {
            wasMessageShown = true;

            // Hacemos un pequeño retraso antes de mostrar el mensaje para que se complete la transición de la escena y el fade-in.
            UIFade fade = FindAnyObjectByType<UIFade>();
            if (fade != null)
            {
                delay = fade.FadeDuration;
            }

            Invoke(nameof(ShowWelcomeMessage), delay); 
        }    
    }

    void ShowWelcomeMessage()
    {
        MessageManager.Instance.ShowMessage(welcomeMessage);
    }
}
