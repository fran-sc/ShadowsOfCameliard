using UnityEngine;

public class GameManager : PersistentSingleton<GameManager>
{
    [SerializeField] AudioClip mainTheme;

    void Start()
    {
        AudioManager.Instance.PlayMusic(mainTheme);
    }


}
