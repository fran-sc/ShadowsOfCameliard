// -----------------------------------------------------------------------------
// Singleton persistente entre escenas para componentes MonoBehaviour
// -----------------------------------------------------------------------------
public class PersistentSingleton<T> : SceneSingleton<T> where T : PersistentSingleton<T>
{
    protected override void Awake()
    {
        base.Awake();

        if (Instance != this)
        {
            return;
        }

        // Desacoplamos en la jerarquía para poder invocar DontDestroyOnLoad
        if (transform.parent != null)
        {
            transform.SetParent(null);
        }

        DontDestroyOnLoad(gameObject);
    }
}