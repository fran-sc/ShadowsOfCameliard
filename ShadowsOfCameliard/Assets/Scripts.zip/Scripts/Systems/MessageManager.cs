using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class MessageManager : PersistentSingleton<MessageManager>, IPlayerCollectObserver
{
    [SerializeField] float charDelay;
    [SerializeField] TextMeshProUGUI txtMessage;
    [SerializeField] GameObject messagePanel;

    PlayerControls controls;

    protected override void Awake()
    {
        base.Awake();

        if (Instance != this)
        {
            return;
        }
    }

    void Start()
    {
        if (Instance != this)
        {
            return;
        }

        controls = InputManager.Instance.Controls;
        controls.UI.Close.performed += OnClosePerformed;

        PlayerCollectSubject.Instance.AddObserver(this);
    }

    protected override void OnDestroy()
    {
        if (Instance == this && controls != null)
        {
            controls.UI.Close.performed -= OnClosePerformed;
        }

        base.OnDestroy();
    }

    void OnClosePerformed(InputAction.CallbackContext context)
    {
        HideMessage();
    }

    public void ShowMessage(string message)
    {
        txtMessage.text = string.Empty;

        Time.timeScale = 0;

        messagePanel.SetActive(true);

        InputManager.Instance.SwitchMap(ControlMap.Dialogue);

        StartCoroutine(TypeText(message));
    }

    void HideMessage()
    {
        StopAllCoroutines();

        messagePanel.SetActive(false);

        Time.timeScale = 1;

        InputManager.Instance.SwitchMap(ControlMap.Player);
    }

    IEnumerator TypeText(string message)
    {
        foreach (char letter in message)
        {
            txtMessage.text += letter;

            yield return new WaitForSecondsRealtime(charDelay);
        }
    }

    public void OnNotify(string itemID)
    {
        SpawnOnceSO resource = ResourcesManager.Instance.GetResource(itemID);

        if (resource != null && !string.IsNullOrEmpty(resource.message))
        {
            /*
            string message = resource.message;

            if (resource.itemType == SpawnOnceSO.SpawnOnceType.Weapon)
            {
                message += " Se añadió a tu inventario.";
            }

            ShowMessage(message);
            */
            ShowMessage(resource.message);
        }
    }
}