using UnityEngine;

// -----------------------------------------------------------------------------
// Singleton genérico para componentes MonoBehaviour ligado a la vida de la escena.
// El genérico T cumple el patrón CRTP (Curiously Recurring Template Pattern) 
// para forzar la instancia (T) al tipo del nuevo componente. 
// Ejemplo:
//      EnemySpawner : SceneSingleton<EnemySpawner>
// -----------------------------------------------------------------------------
public class SceneSingleton<T> : MonoBehaviour where T : SceneSingleton<T>
{   
    private static T instance;
    public static T Instance => instance;
    
    protected virtual void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        else
        {
            instance = (T)this;
        }
    }

    // Limpiamos la instancia al destruir el objeto para evitar referencias colgantes
    protected virtual void OnDestroy()
    {
        if (instance == this)
        {
            instance = null;
        }
    }
}