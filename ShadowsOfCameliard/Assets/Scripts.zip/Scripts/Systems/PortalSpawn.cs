using UnityEngine;

public class PortalSpawn : MonoBehaviour
{
    [SerializeField] string portalName;
    public string PortalName => portalName;

    void Start()
    {
        if (SceneManagement.Instance == null)
        {
            Debug.LogError("No se ha encontrado una instancia de SceneManagement en la escena. Asegúrate de que haya un objeto SceneManagement en la escena.");
            return;
        }
        
        if (SceneManagement.Instance.destPortalName == portalName)
        {
            // Establecemos la posición del jugador
            PlayerController.Instance.transform.position = transform.position;

            // Habilitamos los controles del jugador
            InputManager.Instance.Controls.Player.Enable();

            // Habilitamos el sprite del jugador
            PlayerController.Instance.GetComponentInChildren<SpriteRenderer>().enabled = true;

            // Establecemos la cámara para que siga al jugador
            CameraManager.Instance.SetPlayerCameraFollow();

            // Reseteamos las animaciones del jugador
            PlayerController.Instance.ResetTriggerAnimations();

            // Fade in desde negro
            UIFade.Instance.FadeFromBlack();
        }
    }   
}
