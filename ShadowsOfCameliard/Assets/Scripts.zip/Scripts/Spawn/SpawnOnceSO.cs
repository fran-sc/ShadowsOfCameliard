using System;
using UnityEngine;

[CreateAssetMenu(fileName = "SpawnOnceSO", menuName = "Scriptable Objects/SpawnOnceSO")]
public class SpawnOnceSO : ScriptableObject
{
    [Header("Spawn Once Item Properties")]
    public string itemID; // Identificador único del item
    public int sceneID; // ID de la escena donde aparece el item
    public SpawnOnceType itemType; // Tipo de item
    public SpawnOnceState state; // Estado actual del item (no spawn, to spawn, collected)
    public Vector3 spawnPosition; // Posición donde se debe spawnear el item
    public GameObject itemPrefab; // Prefab del item para instanciar en la escena
    [TextArea(3, 10)]
    public string message; // Mensaje que se muestra al recoger el item

    [Serializable]
    public enum SpawnOnceState
    {
        NotSpawned,
        ToSpawn,
        Spawned,
        Collected,
        Destroyed
    }

    [Serializable]
    public enum SpawnOnceType
    {
        Weapon,
        Health,
        Ammo,
        Key,
        Blockade
    }

}

