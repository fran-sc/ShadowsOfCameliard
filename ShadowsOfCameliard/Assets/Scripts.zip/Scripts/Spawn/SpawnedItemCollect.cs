using UnityEngine;

public class SpawnedItemCollect : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            other.GetComponent<PlayerCollectSubject>()?.NotifyObservers(gameObject.name);

            // Reproducimos el sonido de recogida de objeto
            AudioManager.Instance.PlayEffect(AudioManager.Effect.ItemCollect);

            // Después de notificar a los observadores, destruimos el objeto
            Destroy(gameObject);
        }
    }
}
