using UnityEngine;

public class MessageTest : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        MessageManager.Instance.ShowMessage("¡Has recogido un objeto!");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
